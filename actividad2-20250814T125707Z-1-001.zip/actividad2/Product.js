class Product {
    products = [];

    constructor (products=[]){
        this.products = products;
    }

    addProducts(products){
        if (products.name === ""){

        }
        const id = crypto.randomUUID();
        console.log(id);
    }

    getProducts(){

    }

    getProductById(id){
        
    }


}

module.exports = Product;